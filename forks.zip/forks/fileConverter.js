"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = __importStar(require("fs"));
const sharp_1 = __importDefault(require("sharp"));
const convertToWebp = async () => {
    const fileName = process.argv[2];
    const imageVariants = [
        { sizePercent: 100 },
        { sizePercent: 95 },
        { sizePercent: 90 },
        { sizePercent: 85 },
        { sizePercent: 80 },
        { sizePercent: 75 },
        { sizePercent: 70 },
        { sizePercent: 65 },
        { sizePercent: 60 },
        { sizePercent: 55 },
        { sizePercent: 50 },
        { sizePercent: 45 },
        { sizePercent: 40 },
        { sizePercent: 35 },
        { sizePercent: 30 },
        { sizePercent: 25 },
        { sizePercent: 20 },
        { sizePercent: 15 },
        { sizePercent: 10 },
        { sizePercent: 5 },
    ];
    try {
        //Check if the path exists
        if (!fs.existsSync('uploads/' + fileName)) {
            return;
        }
        for (const sizeP of imageVariants) {
            if (fileName.endsWith('.webp')) {
                await (0, sharp_1.default)(`uploads/${fileName}`, { animated: true })
                    .metadata()
                    .then(({ width }) => (0, sharp_1.default)(`uploads/${fileName}`)
                    // @ts-ignore
                    .resize(Math.round(width / 100 * sizeP.sizePercent))
                    .webp({ quality: 80 })
                    .toFile(`images/${fileName.split('.')[0]}__${sizeP.sizePercent}.webp`));
            }
            else {
                let buffer = await (0, sharp_1.default)(`uploads/${fileName}`)
                    .metadata()
                    .then(({ width }) => (0, sharp_1.default)(`uploads/${fileName}`)
                    // @ts-ignore
                    .resize(Math.round(width / 100 * sizeP.sizePercent))
                    .webp({ quality: 80 })
                    .toBuffer());
                await (0, sharp_1.default)(buffer).toFile(`images/${fileName.split('.')[0]}__${sizeP.sizePercent}.webp`);
            }
        }
        fs.unlinkSync(`uploads/${fileName}`);
        // @ts-ignore
        process.send('File processed successfully:' + fileName);
    }
    catch (error) {
        console.error(error);
    }
};
convertToWebp();
