"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileFilter = void 0;
const fileFilter = (req, file, cb) => {
    if (!file)
        return cb('File is empty', false);
    const extension = file.mimetype.split('/')[1];
    const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    // if its enterprise file, we allow only one file otherwise 5 files for products
    if (allowedExtensions.includes(extension))
        return cb(null, true);
    return cb(null, false);
};
exports.fileFilter = fileFilter;
