"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fileNamer = void 0;
const uuid_1 = require("uuid");
const fileNamer = (req, file, cb) => {
    if (!file)
        return cb('File is empty', false);
    const fileExtension = file.mimetype.split('/')[1];
    const nameSplitByDot = file.originalname.split('.');
    nameSplitByDot.length > 1 && nameSplitByDot.pop();
    const nameWithoutExtension = nameSplitByDot.join('.');
    const fileName = `${nameWithoutExtension.replace(/[^a-zA-Z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-+|-+$/g, '')}_${(0, uuid_1.v4)()}.${fileExtension}`;
    cb(null, fileName);
};
exports.fileNamer = fileNamer;
