"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const fileNamer_1 = require("./helpers/fileNamer");
const fileFilter_1 = require("./helpers/fileFilter");
const multer_1 = __importDefault(require("multer"));
const child_process_1 = require("child_process");
const bootstrap = () => {
    const storage = multer_1.default.diskStorage({
        destination: function (req, file, cb) {
            cb(null, 'uploads/');
        },
        filename: fileNamer_1.fileNamer
    });
    const upload = (0, multer_1.default)({
        storage: storage,
        fileFilter: fileFilter_1.fileFilter,
    });
    const app = (0, express_1.default)();
    // use middleware
    app.use(express_1.default.json());
    app.use((0, cors_1.default)());
    console.log('Server enpoint: (get) /');
    app.get('/', (req, res) => {
        res.send('Hello World!');
    });
    console.log('Server enpoint: (delete) /images');
    app.delete('/images', (req, res) => {
        (0, child_process_1.exec)('rm -rf images/*', (error, stdout, stderr) => {
            if (error) {
                console.error(`error: ${error.message}`);
                return;
            }
            if (stderr) {
                console.error(`stderr: ${stderr}`);
                return;
            }
            console.log(`Images folder cleaned >> ${stdout}`);
        });
        res.send('Delete images success');
    });
    console.log('Server enpoint: (post - multipart/form-data) /upload/images');
    app.post('/upload/images', upload.array('imgs', 30), (req, res) => {
        // @ts-ignore
        // console.log('req.files', req.files);
        // do radom stuff
        (0, child_process_1.exec)('node fileProc.js', (error, stdout, stderr) => {
            if (error) {
                console.error(`error: ${error.message}`);
                return;
            }
            if (stderr) {
                console.error(`stderr: ${stderr}`);
                return;
            }
            console.log(`Process fileProc.js stdout:\n${stdout}`);
        });
        res.send('Upload images success');
    });
    console.log('Server is running on port 3000');
    app.listen(3000);
};
bootstrap();
